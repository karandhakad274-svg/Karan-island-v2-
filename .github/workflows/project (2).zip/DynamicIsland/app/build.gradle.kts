plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.karanai.island"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.karanai.island"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }
    signingConfigs {
        val pass = System.getenv("KS_PASS")
        if (pass != null && rootProject.file("release.jks").exists()) {
            create("release") {
                storeFile = rootProject.file("release.jks")
                storePassword = pass
                keyAlias = "karan"
                keyPassword = pass
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfigs.findByName("release")?.let { signingConfig = it }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
