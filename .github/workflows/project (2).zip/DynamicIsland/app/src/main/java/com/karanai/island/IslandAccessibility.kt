package com.karanai.island

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class IslandAccessibility : AccessibilityService() {
    companion object {
        @Volatile var instance: IslandAccessibility? = null
    }

    override fun onServiceConnected() {
        instance = this
        IslandService.instance?.reload()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        IslandService.instance?.reload()
        return super.onUnbind(intent)
    }
}
