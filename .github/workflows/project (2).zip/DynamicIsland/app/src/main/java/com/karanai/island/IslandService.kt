package com.karanai.island

import android.animation.ValueAnimator
import android.app.Notification
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import android.util.TypedValue
import android.hardware.display.DisplayManager
import android.view.Display
import android.view.Surface
import android.widget.FrameLayout
import android.view.animation.AccelerateInterpolator
import kotlin.random.Random
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class IslandService : NotificationListenerService() {

    companion object {
        @Volatile var instance: IslandService? = null
    }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var sp: SharedPreferences
    private var connected = false

    private var root: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private var emoji: TextView? = null
    private var icon: ImageView? = null
    private var textCol: LinearLayout? = null
    private var title: TextView? = null
    private var sub: TextView? = null
    private var controls: LinearLayout? = null
    private var playBtn: TextView? = null
    private var parts: List<View> = emptyList()
    private var anim: ValueAnimator? = null

    private var mode = 0 // 0 idle, 1 charging, 2 music, 3 notification
    private var curPI: PendingIntent? = null
    private var controller: MediaController? = null
    private var msm: MediaSessionManager? = null
    private var lastTitle: String? = null
    private var lastPlaying = false

    private val collapseR = Runnable { collapse() }
    private val rebuildR = Runnable { rebuild() }
    private val prefL = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        h.removeCallbacks(rebuildR); h.postDelayed(rebuildR, 200)
    }

    // ---------- helpers ----------
    private fun scale() = sp.getInt("scale", 100) / 100f
    private fun d(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics)
    private fun ds(v: Float) = (d(v) * scale()).toInt()
    private fun dur() = sp.getInt("anim", 400).toLong()
    private fun idleVisible() = sp.getBoolean("idle", true)
    private fun rot(): Int = try {
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).rotation
    } catch (e: Exception) { Surface.ROTATION_0 }
    private fun land() = rot() == Surface.ROTATION_90 || rot() == Surface.ROTATION_270
    private fun idleW() = if (!idleVisible()) 1 else if (land()) ds(30f) else ds(96f)
    private fun idleH() = if (!idleVisible()) 1 else if (land()) ds(96f) else ds(30f)

    @Suppress("DEPRECATION")
    private fun realSize(): Pair<Int, Int> {
        val m = android.util.DisplayMetrics()
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    private fun place(p: WindowManager.LayoutParams) {
        val top = d(sp.getInt("top", 10).toFloat()).toInt()
        val sh = d(sp.getInt("shift", 0).toFloat()).toInt()
        p.x = 0; p.y = 0
        when (rot()) {
            Surface.ROTATION_90 -> { p.gravity = Gravity.START or Gravity.CENTER_VERTICAL; p.x = top; p.y = -sh }
            Surface.ROTATION_270 -> { p.gravity = Gravity.END or Gravity.CENTER_VERTICAL; p.x = top; p.y = sh }
            Surface.ROTATION_180 -> { p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; p.y = top; p.x = -sh }
            else -> { p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; p.y = top; p.x = sh }
        }
    }

    private var ovType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private var lastRot = 0
    private var fxView: FrameLayout? = null
    private val EMOJIS = arrayOf("🐵", "❤️", "⭐", "🔥", "👻", "🐱")

    private val dispL = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            val r = rot()
            if (r != lastRot) {
                lastRot = r
                h.removeCallbacks(rebuildR); h.postDelayed(rebuildR, 100)
            }
        }
    }
    private fun playing() = controller?.playbackState?.state == PlaybackState.STATE_PLAYING

    // ---------- lifecycle ----------
    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        start()
    }

    override fun onListenerDisconnected() {
        stop(); instance = null
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        stop(); instance = null
        super.onDestroy()
    }

    private val power = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (!sp.getBoolean("charging", true)) return
            when (i.action) {
                Intent.ACTION_POWER_CONNECTED -> showCharging(true)
                Intent.ACTION_POWER_DISCONNECTED -> showCharging(false)
            }
        }
    }

    private val sessL = MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    private val cb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            val p = state?.state == PlaybackState.STATE_PLAYING
            updatePlayBtn(p)
            if (p != lastPlaying) {
                lastPlaying = p
                if (p && sp.getBoolean("music", true)) showMusic()
            }
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            val t = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
            if (t != null && t != lastTitle) {
                lastTitle = t
                if (sp.getBoolean("music", true) && playing()) showMusic()
            }
        }
    }

    private fun start() {
        if (connected) return
        connected = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        sp = Prefs.sp(this)
        sp.registerOnSharedPreferenceChangeListener(prefL)
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(power, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(power, f)
        lastRot = rot()
        try { getSystemService(DisplayManager::class.java).registerDisplayListener(dispL, h) } catch (e: Exception) { }
        rebuild()
        try {
            msm = getSystemService(MediaSessionManager::class.java)
            val cn = ComponentName(this, IslandService::class.java)
            msm?.addOnActiveSessionsChangedListener(sessL, cn)
            pick(msm?.getActiveSessions(cn))
        } catch (e: Exception) { }
    }

    private fun stop() {
        if (!connected) return
        connected = false
        h.removeCallbacksAndMessages(null)
        try { sp.unregisterOnSharedPreferenceChangeListener(prefL) } catch (e: Exception) { }
        try { unregisterReceiver(power) } catch (e: Exception) { }
        try { getSystemService(DisplayManager::class.java).unregisterDisplayListener(dispL) } catch (e: Exception) { }
        try { msm?.removeOnActiveSessionsChangedListener(sessL) } catch (e: Exception) { }
        try { controller?.unregisterCallback(cb) } catch (e: Exception) { }
        controller = null
        removeView()
    }

    fun reload() { if (connected) h.post { rebuild() } }

    fun refresh() { if (connected && root == null) rebuild() }

    // ---------- media ----------
    private fun pick(list: List<MediaController>?) {
        val c = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        if (c?.sessionToken == controller?.sessionToken) return
        try { controller?.unregisterCallback(cb) } catch (e: Exception) { }
        controller = c
        lastTitle = null
        lastPlaying = false
        c?.registerCallback(cb, h)
    }

    private fun updatePlayBtn(p: Boolean) { playBtn?.text = if (p) "⏸" else "▶" }

    // ---------- notifications ----------
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!connected || !sp.getBoolean("notif", true)) return
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if ((n.flags and (Notification.FLAG_ONGOING_EVENT or Notification.FLAG_GROUP_SUMMARY)) != 0) return
        if (n.category == Notification.CATEGORY_TRANSPORT || n.category == Notification.CATEGORY_PROGRESS) return
        if (!Prefs.allowed(this, sbn.packageName)) return
        val ex = n.extras
        val t = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val txt = (ex.getCharSequence(Notification.EXTRA_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString() ?: ""
        val ic = try { packageManager.getApplicationIcon(sbn.packageName) } catch (e: Exception) { null }
        h.post { showNotif(t, txt, ic, n.contentIntent) }
    }

    // ---------- view ----------
    private fun removeView() {
        anim?.cancel()
        fxView?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        fxView = null
        root?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        root = null
    }

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp * scale())
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }

    private fun rebuild() {
        if (!connected) return
        h.removeCallbacks(collapseR)
        removeView()
        val acc = IslandAccessibility.instance
        if (acc == null && !Settings.canDrawOverlays(this)) return
        val ctx: Context = acc ?: this
        wm = ctx.getSystemService(WINDOW_SERVICE) as WindowManager
        ovType = if (acc != null) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        else WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

        val bg = GradientDrawable().apply {
            setColor(sp.getInt("color", Color.BLACK))
            when (sp.getInt("shape", 0)) {
                1 -> cornerRadius = d(16f) * scale()
                2 -> cornerRadius = d(4f)
                3 -> { cornerRadius = 1000f; setStroke(ds(2f).coerceAtLeast(2), 0xFFFF7A3D.toInt()) }
                else -> cornerRadius = 1000f
            }
        }
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = bg
            setPadding(ds(12f), 0, ds(12f), 0)
        }
        val em = tv("", 22f, Color.WHITE)
        val ic = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, v.width / 4f)
                }
            }
            clipToOutline = true
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val t = tv("", 14f, Color.WHITE, true)
        val s = tv("", 12f, 0xFFB0B0B0.toInt())
        col.addView(t); col.addView(s)

        val ctr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val prev = tv("⏮", 20f, Color.WHITE)
        val play = tv("⏸", 20f, Color.WHITE)
        val next = tv("⏭", 20f, Color.WHITE)
        for (b in listOf(prev, play, next)) { b.setPadding(ds(7f), 0, ds(7f), 0); ctr.addView(b) }
        prev.setOnClickListener { controller?.transportControls?.skipToPrevious(); keep() }
        next.setOnClickListener { controller?.transportControls?.skipToNext(); keep() }
        play.setOnClickListener {
            controller?.let { c ->
                if (playing()) c.transportControls.pause() else c.transportControls.play()
            }
            keep()
        }

        r.addView(em)
        r.addView(ic, LinearLayout.LayoutParams(ds(38f), ds(38f)))
        r.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = ds(10f); marginEnd = ds(6f)
        })
        r.addView(ctr)

        r.setOnClickListener {
            when {
                mode == 0 && playing() -> showMusic()
                mode == 0 -> startActivity(
                    Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                mode == 3 && curPI != null -> {
                    try { curPI?.send() } catch (e: Exception) { }
                    collapse()
                }
                else -> collapse()
            }
        }

        val p = WindowManager.LayoutParams(
            idleW(), idleH(),
            ovType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        place(p)
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        emoji = em; icon = ic; textCol = col; title = t; sub = s; controls = ctr; playBtn = play
        parts = listOf(em, ic, col, ctr)
        parts.forEach { it.visibility = View.GONE }
        if (!idleVisible()) r.visibility = View.INVISIBLE
        try { wm.addView(r, p) } catch (e: Exception) { return }
        root = r; lp = p; mode = 0
    }

    private fun animateTo(w: Int, hh: Int) {
        val p = lp ?: return
        val v = root ?: return
        anim?.cancel()
        val w0 = p.width
        val h0 = p.height
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = dur()
            interpolator = OvershootInterpolator(1.1f)
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                p.width = (w0 + (w - w0) * f).toInt().coerceAtLeast(1)
                p.height = (h0 + (hh - h0) * f).toInt().coerceAtLeast(1)
                try { wm.updateViewLayout(v, p) } catch (e: Exception) { a.cancel() }
            }
            start()
        }
    }

    private fun expand(m: Int, w: Float, hh: Float, holdMs: Long) {
        val r = root ?: return
        mode = m
        r.visibility = View.VISIBLE
        h.removeCallbacks(collapseR)
        val maxW = realSize().first - d(16f).toInt()
        animateTo(minOf(ds(w), maxW), ds(hh))
        parts.forEach {
            it.animate().cancel()
            if (it.visibility == View.VISIBLE) {
                it.alpha = 0f
                it.animate().alpha(1f).setStartDelay(dur() / 3).setDuration(dur() / 2).start()
            }
        }
        h.postDelayed(collapseR, holdMs)
    }

    private fun keep() {
        h.removeCallbacks(collapseR); h.postDelayed(collapseR, 5000)
    }

    private fun collapse() {
        val r = root ?: return
        h.removeCallbacks(collapseR)
        mode = 0
        parts.forEach { it.animate().cancel(); it.animate().alpha(0f).setStartDelay(0).setDuration(120).start() }
        animateTo(idleW(), idleH())
        h.postDelayed({
            if (mode == 0) {
                parts.forEach { it.visibility = View.GONE }
                if (!idleVisible()) r.visibility = View.INVISIBLE
            }
        }, dur() + 50)
    }

    private fun setContent(e: String?, ic: Drawable?, t: String, s: String?, ctrl: Boolean) {
        emoji?.apply { text = e ?: ""; visibility = if (e != null) View.VISIBLE else View.GONE }
        icon?.apply { setImageDrawable(ic); visibility = if (ic != null) View.VISIBLE else View.GONE }
        title?.text = t
        sub?.apply { text = s ?: ""; visibility = if (s.isNullOrEmpty()) View.GONE else View.VISIBLE }
        textCol?.visibility = View.VISIBLE
        controls?.visibility = if (ctrl) View.VISIBLE else View.GONE
    }

    // ---------- public show functions ----------
    fun showCharging(on: Boolean) {
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scl = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (scl > 0) lvl * 100 / scl else lvl
        setContent(if (on) "⚡" else "🔌", null, "$pct%", if (on) "चार्जिंग शुरू" else "चार्जर हटाया", false)
        curPI = null
        expand(1, 210f, 50f, 3000)
        fx("⚡")
    }

    fun showMusic() {
        val m = controller?.metadata
        val t = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Demo Song"
        val a = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "करण AI स्टूडियो"
        val art = m?.getBitmap(MediaMetadata.METADATA_KEY_ART) ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
        setContent(
            if (art == null) "🎵" else null,
            art?.let { BitmapDrawable(resources, it) },
            t, a, true
        )
        updatePlayBtn(playing())
        curPI = null
        expand(2, 320f, 68f, 5000)
        fx(null)
    }

    fun showNotif(t: String, txt: String, ic: Drawable?, pi: PendingIntent?) {
        setContent(if (ic == null) "🔔" else null, ic, t, txt, false)
        curPI = pi
        expand(3, 320f, 68f, 4500)
        fx(null)
    }

    private fun fx(override: String?) {
        if (!sp.getBoolean("fx", true) || root == null) return
        val emo = override ?: EMOJIS[sp.getInt("fx_emoji", 0).coerceIn(0, EMOJIS.size - 1)]
        val style = sp.getInt("fx_style", 0)
        fxView?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        val (sw, sh2) = realSize()
        val edge = d(sp.getInt("top", 10).toFloat()).toInt() + ds(15f)
        val sh = d(sp.getInt("shift", 0).toFloat()).toInt()
        val (sx, sy) = when (rot()) {
            Surface.ROTATION_90 -> Pair(edge, sh2 / 2 - sh)
            Surface.ROTATION_270 -> Pair(sw - edge, sh2 / 2 + sh)
            Surface.ROTATION_180 -> Pair(sw / 2 - sh, sh2 - edge)
            else -> Pair(sw / 2 + sh, edge)
        }
        val f = FrameLayout(this)
        val half = d(14f)
        for (i in 0 until 7) {
            val t = TextView(this).apply {
                text = emo; setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f); visibility = View.INVISIBLE
            }
            f.addView(t, FrameLayout.LayoutParams(-2, -2))
            if (style == 0) {
                t.translationX = sx + d(Random.nextInt(-60, 61).toFloat()) - half
                t.translationY = sy.toFloat()
                t.animate().setStartDelay(i * 140L).setDuration(1500)
                    .translationY(sy + d(260f))
                    .rotation(Random.nextInt(-45, 46).toFloat())
                    .setInterpolator(AccelerateInterpolator(0.8f))
                    .withStartAction { t.visibility = View.VISIBLE }
                    .withEndAction { t.animate().setStartDelay(0).setDuration(250).alpha(0f).start() }
                    .start()
            } else {
                t.translationX = sx + d(Random.nextInt(-110, 111).toFloat()) - half
                t.translationY = sy + d(Random.nextInt(20, 160).toFloat())
                t.scaleX = 0f; t.scaleY = 0f
                t.animate().setStartDelay(i * 170L).setDuration(350)
                    .scaleX(1.3f).scaleY(1.3f)
                    .setInterpolator(OvershootInterpolator())
                    .withStartAction { t.visibility = View.VISIBLE }
                    .withEndAction {
                        t.animate().setStartDelay(600).setDuration(300).alpha(0f).scaleX(0f).scaleY(0f).start()
                    }
                    .start()
            }
        }
        val lpf = WindowManager.LayoutParams(
            -1, -1, ovType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lpf.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try { wm.addView(f, lpf) } catch (e: Exception) { return }
        fxView = f
        h.postDelayed({
            try { wm.removeView(f) } catch (e: Exception) { }
            if (fxView === f) fxView = null
        }, 3800)
    }

    fun demo(kind: Int) {
        h.post {
            when (kind) {
                0 -> showCharging(true)
                1 -> showMusic()
                else -> showNotif("करण AI स्टूडियो", "Dynamic Island चालू है 🎉", null, null)
            }
        }
    }
}
