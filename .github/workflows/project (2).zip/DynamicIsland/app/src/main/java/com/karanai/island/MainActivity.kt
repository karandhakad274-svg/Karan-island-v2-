package com.karanai.island

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var sp: SharedPreferences
    private lateinit var ovStatus: TextView
    private lateinit var nlStatus: TextView
    private lateinit var accStatus: TextView
    private val BG = 0xFF0E0E14.toInt()
    private val CARD = 0xFF1A1A24.toInt()
    private val ACC = 0xFFFF7A3D.toInt()
    private val colorViews = ArrayList<View>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun card(parent: LinearLayout, heading: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(CARD); cornerRadius = dp(18).toFloat() }
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        c.addView(text(heading, 16f, ACC, true))
        parent.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        return c
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setOnClickListener { onClick() }
    }

    private fun switchRow(parent: LinearLayout, label: String, key: String, def: Boolean) {
        parent.addView(Switch(this).apply {
            text = label; setTextColor(Color.WHITE); textSize = 15f
            isChecked = sp.getBoolean(key, def)
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, c -> sp.edit().putBoolean(key, c).apply() }
        })
    }

    private fun seekRow(parent: LinearLayout, label: String, key: String, min: Int, max: Int, def: Int, unit: String) {
        val cur = sp.getInt(key, def)
        val lab = text("$label: $cur$unit", 14f)
        parent.addView(lab, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        parent.addView(SeekBar(this).apply {
            this.max = max - min; progress = cur - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    lab.text = "$label: ${p + min}$unit"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    sp.edit().putInt(key, (s?.progress ?: 0) + min).apply()
                }
            })
        })
    }

    private fun choiceRow(parent: LinearLayout, title: String, key: String, labels: List<String>, def: Int) {
        parent.addView(text(title, 14f), LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10) })
        val g = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val cur = sp.getInt(key, def)
        labels.forEachIndexed { i, l ->
            val rb = RadioButton(this).apply {
                text = l; setTextColor(Color.WHITE); id = View.generateViewId(); isChecked = (i == cur)
            }
            g.addView(rb)
            rb.setOnClickListener { sp.edit().putInt(key, i).apply() }
        }
        parent.addView(HorizontalScrollView(this).apply { addView(g) })
    }

    private fun paintColors() {
        val cur = sp.getInt("color", Color.BLACK)
        colorViews.forEachIndexed { i, v ->
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Prefs.COLORS[i])
                setStroke(dp(3), if (Prefs.COLORS[i] == cur) ACC else 0xFF555566.toInt())
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sp = Prefs.sp(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        val sv = ScrollView(this).apply { setBackgroundColor(BG) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        sv.addView(col)
        sv.setOnApplyWindowInsetsListener { v, ins ->
            @Suppress("DEPRECATION")
            v.setPadding(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
            ins
        }

        // header
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(this).apply { setImageResource(R.mipmap.ic_launcher) }, LinearLayout.LayoutParams(dp(76), dp(76)))
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ht.addView(text("Karan Island", 24f, Color.WHITE, true))
        ht.addView(text("by करण AI स्टूडियो", 13f, ACC))
        head.addView(ht, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(12) })
        col.addView(head)

        // permissions
        val perm = card(col, "1. Permissions (ज़रूरी)")
        ovStatus = text("", 14f); nlStatus = text("", 14f)
        perm.addView(ovStatus)
        perm.addView(button("Overlay permission दो") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        perm.addView(nlStatus)
        perm.addView(button("Notification access दो") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        accStatus = text("", 14f)
        perm.addView(accStatus)
        perm.addView(button("Accessibility चालू करो (Lock screen के लिए)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        perm.addView(button("Battery: Unrestricted करो (24 घंटे के लिए)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        perm.addView(text("अगर Notification access ग्रे दिखे: Settings → Apps → Karan Island → ⋮ → \"Allow restricted settings\", फिर दोबारा कोशिश करो।", 12f, 0xFF9999AA.toInt()))

        // features
        val feat = card(col, "2. Features")
        switchRow(feat, "⚡ चार्जिंग animation", "charging", true)
        switchRow(feat, "🎵 म्यूज़िक कंट्रोल", "music", true)
        switchRow(feat, "🔔 नोटिफ़िकेशन", "notif", true)
        switchRow(feat, "छोटा pill हमेशा दिखाओ", "idle", true)

        // customize
        val cus = card(col, "3. Customize")
        cus.addView(text("Island का रंग", 14f), LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Prefs.COLORS.forEachIndexed { i, c ->
            val v = View(this)
            v.setOnClickListener { sp.edit().putInt("color", c).apply(); paintColors() }
            colorViews.add(v)
            row.addView(v, LinearLayout.LayoutParams(dp(40), dp(40)).apply { topMargin = dp(8); marginEnd = dp(10) })
        }
        cus.addView(row)
        paintColors()
        seekRow(cus, "किनारे पर खिसकाओ (कैमरा बीच में न हो तो)", "shift", -150, 150, 0, "dp")
        cus.addView(text("लैंडस्केप में island अपने आप कैमरे वाले किनारे पर चला जाएगा।", 12f, 0xFF9999AA.toInt()))
        seekRow(cus, "साइज़", "scale", 80, 140, 100, "%")
        seekRow(cus, "ऊपर से दूरी", "top", 0, 80, 10, "dp")
        seekRow(cus, "Animation टाइम", "anim", 150, 800, 400, "ms")

        // apps
        val apps = card(col, "4. नोटिफ़िकेशन वाले ऐप्स")
        switchRow(apps, "सभी ऐप्स", "all_apps", true)
        apps.addView(text("\"सभी ऐप्स\" बंद करो तो सिर्फ़ नीचे चुने हुए ऐप्स दिखेंगे:", 12f, 0xFF9999AA.toInt()))
        Prefs.APPS.forEach { switchRow(apps, it.label, "app_" + it.label, true) }

        // shape + fx
        val shp = card(col, "5. शेप और इमोजी effect")
        choiceRow(shp, "Island का शेप", "shape", listOf("गोली", "डिब्बा", "चौकोर", "नियॉन"), 0)
        switchRow(shp, "इमोजी effect (नोटिफ़िकेशन/चार्जिंग पर)", "fx", true)
        choiceRow(shp, "कौन सा इमोजी", "fx_emoji", listOf("🐵", "❤️", "⭐", "🔥", "👻", "🐱"), 0)
        choiceRow(shp, "Effect का तरीका", "fx_style", listOf("⬇ उतरना", "💥 छपना"), 0)

        // test
        val test = card(col, "6. Test करो")
        val tr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("⚡ चार्ज", "🎵 म्यूज़िक", "🔔 नोटिफ़").forEachIndexed { i, l ->
            tr.addView(button(l) {
                val s = IslandService.instance
                if (s == null) Toast.makeText(this, "पहले दोनों permissions चालू करो", Toast.LENGTH_SHORT).show()
                else s.demo(i)
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        test.addView(tr)

        col.addView(text("Made with ❤️ by करण AI स्टूडियो", 13f, 0xFF9999AA.toInt()).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })

        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        val ov = Settings.canDrawOverlays(this)
        ovStatus.text = if (ov) "✅ Overlay permission चालू" else "❌ Overlay permission चाहिए"
        val nl = (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)
        nlStatus.text = if (nl) "✅ Notification access चालू" else "❌ Notification access चाहिए"
        val ac = (Settings.Secure.getString(contentResolver, "enabled_accessibility_services") ?: "").contains("$packageName/")
        accStatus.text = if (ac) "✅ Accessibility चालू (Lock screen पर दिखेगा)" else "❌ Lock screen के लिए Accessibility चाहिए"
        IslandService.instance?.refresh()
    }
}
