package com.karanai.island

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

data class AppDef(val label: String, val pkgs: List<String>)

object Prefs {
    val APPS = listOf(
        AppDef("WhatsApp", listOf("com.whatsapp", "com.whatsapp.w4b")),
        AppDef("Instagram", listOf("com.instagram.android")),
        AppDef("Telegram", listOf("org.telegram.messenger")),
        AppDef("Gmail", listOf("com.google.android.gm")),
        AppDef("YouTube", listOf("com.google.android.youtube")),
        AppDef("Snapchat", listOf("com.snapchat.android")),
        AppDef("Facebook", listOf("com.facebook.katana")),
        AppDef("Messages", listOf("com.google.android.apps.messaging", "com.samsung.android.messaging")),
        AppDef("Phone", listOf("com.google.android.dialer", "com.samsung.android.incallui", "com.android.server.telecom"))
    )
    val COLORS = intArrayOf(
        Color.BLACK, 0xFF0B1020.toInt(), 0xFF2A1065.toInt(),
        0xFF0A3D91.toInt(), 0xFF0B3D2E.toInt(), 0xFF5A0F1A.toInt()
    )

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("island", Context.MODE_PRIVATE)

    fun allowed(c: Context, pkg: String): Boolean {
        val p = sp(c)
        if (p.getBoolean("all_apps", true)) return true
        return APPS.any { a -> pkg in a.pkgs && p.getBoolean("app_" + a.label, true) }
    }
}
